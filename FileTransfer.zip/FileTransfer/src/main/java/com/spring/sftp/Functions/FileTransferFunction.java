package com.spring.sftp.Functions;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class FileTransferFunction {
	
	List<String> filename= new ArrayList<>();
	

	public List<String> FileList(String localdirlocation)
	{

		try {
			DirectoryStream<Path> list = Files.newDirectoryStream(Paths.get(localdirlocation));
			for(Path path:list)
			{
				filename.add(path.toString());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return filename;
	}
	
	public void deletefiles(String filelist)
	{
		try {
			new File(filelist).delete();
		}
		catch(Exception ex) {
		System.out.println("Not able to delete the file : "+filename);
		}
		
	}
	
	public void movefiles(String filelist,String faileddir)
	{
		Path source = Paths.get(filelist);
        Path target = Paths.get(faileddir);
		try {
			Files.move(source, target.resolve(source.getFileName()),StandardCopyOption.REPLACE_EXISTING);			
		}
		catch(Exception ex)
		{System.out.println("Not able to move the file : "+ex);}
	}
	
	public java.sql.Timestamp getsqlDate(){
		java.util.Date utilDate = new java.util.Date();
		java.sql.Timestamp sqlDate = new java.sql.Timestamp(utilDate.getTime());
		return sqlDate;
	}
	
	public String  filenamereader (String filefullpath)
	{
		try {
		String[] filename = filefullpath.split("\\\\");
		return filename[filename.length-1];
		}
		catch(Exception ex) {System.out.println(ex);}
		return null;
	}
	
}
