package com.spring.sftp.dbupdate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.sftp.properties.FilemoverProperty;

@Component
public class DBStatusUpdate {
	
	@Autowired
	FilemoverProperty props;
	
	public void updateDBStatus(String name,String status,String date) {
	
	try {
		Class.forName(props.getDbdriver());
		//Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/vijay","root","Sparky@6@21998");
		Connection connect = DriverManager.getConnection(props.getDburl(),props.getDbusername(),props.getPassword());
		insermethod(connect,name,status,date);
		connect.close();  
		}catch (Exception e)
		{System.out.println(e);}
	}
	
	public void insermethod(Connection con,String name,String status,String date) throws SQLException{
		{
			PreparedStatement stmt=con.prepareStatement("insert into vijay.sftpaudit values(?,?,?)");  
			stmt.setString(1, name);//1 specifies the first parameter in the query  
			stmt.setString(2, status);
			stmt.setString(3, date);
			stmt.executeUpdate();
		}
	}

}
