package com.spring.sftp.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class FilemoverProperty {

	@Value("${localInputFilepath}")
	public String InputPath;
	
	@Value("${remotelocation}")
	public String remote;
	
	@Value("${key}")
	public String Pemfile;
	
	@Value("${dbusername}")
	public String dbusername;
	
	@Value("${password}")
	public String password;
	
	@Value("${dbdriver}")
	public String dbdriver;
	
	@Value("${dburl}")
	public String dburl;
	
	@Value("${failedPath}")
	public String faileddir;
	
	@Value("${sftp.host}")
	public String host;
	
	@Value("${sftp.port}")
	public String port;
	
	@Value("${sftp.username}")
	public String sftpusername;
	
	@Value("${sftp.Identity}")
	public String Identity;
	
	@Value("${sftp.sessionTimeout}")
	public Integer sessionTimeout;
	
	@Value("${sftp.channelTimeout}")
	public Integer channelTimeout;

	public String getInputPath() {
		return InputPath;
	}

	public void setInputPath(String inputPath) {
		InputPath = inputPath;
	}

	public String getRemote() {
		return remote;
	}

	public void setRemote(String remote) {
		this.remote = remote;
	}

	public String getPemfile() {
		return Pemfile;
	}

	public void setPemfile(String pemfile) {
		Pemfile = pemfile;
	}

	public String getDbusername() {
		return dbusername;
	}

	public void setDbusername(String dbusername) {
		this.dbusername = dbusername;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDbdriver() {
		return dbdriver;
	}

	public void setDbdriver(String dbdriver) {
		this.dbdriver = dbdriver;
	}

	public String getDburl() {
		return dburl;
	}

	public void setDburl(String dburl) {
		this.dburl = dburl;
	}

	public String getFaileddir() {
		return faileddir;
	}

	public void setFaileddir(String faileddir) {
		this.faileddir = faileddir;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getSftpusername() {
		return sftpusername;
	}

	public void setSftpusername(String sftpusername) {
		this.sftpusername = sftpusername;
	}

	public String getIdentity() {
		return Identity;
	}

	public void setIdentity(String identity) {
		Identity = identity;
	}

	public Integer getSessionTimeout() {
		return sessionTimeout;
	}

	public void setSessionTimeout(Integer sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}

	public Integer getChannelTimeout() {
		return channelTimeout;
	}

	public void setChannelTimeout(Integer channelTimeout) {
		this.channelTimeout = channelTimeout;
	}
}
