package com.spring.sftp.Entities;

import org.springframework.stereotype.Service;

@Service
public interface FileTransferService {

	boolean uploadFile(String localFilePath, String remoteFilePath);
}
