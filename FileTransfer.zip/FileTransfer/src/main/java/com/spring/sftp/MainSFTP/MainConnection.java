package com.spring.sftp.MainSFTP;


import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.spring.sftp.Functions.FileTransferFunction;
import com.spring.sftp.dbupdate.DBStatusUpdate;
import com.spring.sftp.Entities.FileTransferService;

import com.spring.sftp.properties.FilemoverProperty;

@Component
public class MainConnection implements CommandLineRunner {

	@Autowired
	private FileTransferService fileTransferService;
	
	@Autowired
	private FileTransferFunction transferfunction;
	
	@Autowired
	private FilemoverProperty props;
	
	@Autowired
	private DBStatusUpdate dbupdate;
	
	private org.slf4j.Logger logger = LoggerFactory.getLogger(MainConnection.class);
	
	public String DBStatus_Success ="SUCCESS";
	public String DBStatus_Failed ="FAILED";
	
	@Override
	public void run(String... args) throws Exception {		
        logger.info("Start upload file");
        List<String> filelist =transferfunction.FileList(props.getInputPath());
        for(String f: filelist)
        {
        	System.out.println("filename --> "+ f);
		boolean isUploaded = fileTransferService.uploadFile(f,props.getRemote());
		if(isUploaded)
			{
				dbupdate.updateDBStatus(transferfunction.filenamereader(f), DBStatus_Success,transferfunction.getsqlDate().toString());
				transferfunction.deletefiles(f);
				logger.info("Upload result: " + String.valueOf(isUploaded));
				
			}
		else {
			System.out.println("Moved to failed directory --> "+ f);
			dbupdate.updateDBStatus(transferfunction.filenamereader(f), DBStatus_Failed,transferfunction.getsqlDate().toString());
			transferfunction.movefiles(f,props.getFaileddir());
		}
		}
	}
}
