package com.spring.sftp.Repos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.spring.sftp.properties.*;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.spring.sftp.Entities.*;

@Repository
public class SftpService implements FileTransferService  {
	
	//private Logger logger = (Logger) LoggerFactory.getLogger(SftpService.class);
	@Autowired
	FilemoverProperty props;

	@Override
	public boolean uploadFile(String localFilePath, String remoteFilePath) {
		// TODO Auto-generated method stub
		try {
			JSch jSch = new JSch();
			Session session = jSch.getSession(props.getSftpusername(),props.getHost(),Integer.parseInt(props.getPort()));
			session.setConfig("StrictHostKeyChecking", "no");
			jSch.addIdentity(props.getIdentity());
			session.connect(props.getSessionTimeout());
			Channel channel = session.openChannel("sftp");
			channel.connect(props.getChannelTimeout());
			ChannelSftp sftpchannel = (ChannelSftp) channel;
			sftpchannel.put(localFilePath, remoteFilePath);
			sftpchannel.exit();
			session.disconnect();
			return true;
		} catch(SftpException | JSchException ex) {
			//logger.error("Error upload file", ex);
			System.out.println("Error upload file"+ ex);
		}
		
		return false;
	}
		
}
